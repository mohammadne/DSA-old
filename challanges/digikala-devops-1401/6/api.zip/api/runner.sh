#!/bin/sh

go run app/*.go
